#pragma once

#import "RNSDefines.h"
#import "RNSEnums.h"
#import "RNSReactBaseView.h"
#import "RNSSplitHostProviders.h"

NS_ASSUME_NONNULL_BEGIN

@class RNSSplitHostController;
@class RNSSplitScreenComponentView;

/**
 * @class RNSSplitHostComponentView
 * @brief A view component representing top-level native component for SplitView.
 *
 * Responsible for managing multi-column layouts via associated native UISplitViewController.
 * Manages updates to the layout properties, column configuration, and event emission.
 */
@interface RNSSplitHostComponentView : RNSReactBaseView <RNSSplitHostAppearanceProvider, RNSSplitHostBehaviorProvider>

- (nonnull NSMutableArray<RNSSplitScreenComponentView *> *)reactSubviews;

- (void)splitScreenDidChangeActivityMode:(nonnull RNSSplitScreenComponentView *)screen;

@property (nonatomic, nonnull, strong, readonly) RNSSplitHostController *splitHostController;

@end

#pragma mark - Props

/**
 * @category Props
 * @brief Definitions for React Native props. They back the appearance and behavior providers of the Split host
 * controller.
 */
@interface RNSSplitHostComponentView ()

@property (nonatomic, readonly) UISplitViewControllerSplitBehavior preferredSplitBehavior;
@property (nonatomic, readonly) UISplitViewControllerPrimaryEdge primaryEdge;
@property (nonatomic, readonly) UISplitViewControllerDisplayMode preferredDisplayMode;
@property (nonatomic, readonly) UISplitViewControllerDisplayModeButtonVisibility displayModeButtonVisibility;
#if !TARGET_OS_TV
@property (nonatomic, readonly) UISplitViewControllerBackgroundStyle primaryBackgroundStyle;
#endif // !TARGET_OS_TV
@property (nonatomic, readonly) BOOL presentsWithGesture;
@property (nonatomic, readonly) BOOL showSecondaryToggleButton;
@property (nonatomic, readonly) BOOL showInspector;
@property (nonatomic, readonly) BOOL hasCustomTopColumnForCollapsing;
@property (nonatomic, readonly) UISplitViewControllerColumn topColumnForCollapsingColumn;

@property (nonatomic, readonly) double minimumPrimaryColumnWidth;
@property (nonatomic, readonly) double maximumPrimaryColumnWidth;
@property (nonatomic, readonly) double preferredPrimaryColumnWidthOrFraction;
@property (nonatomic, readonly) double minimumSupplementaryColumnWidth;
@property (nonatomic, readonly) double maximumSupplementaryColumnWidth;
@property (nonatomic, readonly) double preferredSupplementaryColumnWidthOrFraction;

#if RNS_IPHONE_OS_VERSION_AVAILABLE(26_0)
@property (nonatomic, readonly) double minimumSecondaryColumnWidth;
@property (nonatomic, readonly) double preferredSecondaryColumnWidthOrFraction;
@property (nonatomic, readonly) double minimumInspectorColumnWidth;
@property (nonatomic, readonly) double maximumInspectorColumnWidth;
@property (nonatomic, readonly) double preferredInspectorColumnWidthOrFraction;
#endif // RNS_IPHONE_OS_VERSION_AVAILABLE(26_0)

@property (nonatomic, readonly) RNSOrientation orientation;
@property (nonatomic, readonly) UIUserInterfaceStyle colorScheme;

@end

NS_ASSUME_NONNULL_END
