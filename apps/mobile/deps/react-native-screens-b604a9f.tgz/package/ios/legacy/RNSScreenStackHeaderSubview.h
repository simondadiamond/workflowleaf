#pragma once

#if defined(__cplusplus)
#import <React/RCTConvert.h>
#import <React/RCTViewManager.h>
#endif // __cplusplus
#import "RNSLegacyEnums.h"
#import "RNSReactBaseView.h"

NS_ASSUME_NONNULL_BEGIN

@interface RNSScreenStackHeaderSubview : RNSReactBaseView

@property (nonatomic) RNSScreenStackHeaderSubviewType type;
@property (nonatomic, readwrite) BOOL synchronousShadowStateUpdatesEnabled;

@property (nonatomic, weak) UIView *reactSuperview;

/**
 * Updates state of the header subview shadow node in shadow tree.
 * This method updates state of header subview shadow node only.
 */
- (void)updateShadowStateWithFrame:(CGRect)frame;

/**
 * Updates state of the header subview shadow node in shadow tree in context of given ancestor view.
 * This method updates state of header subview shadow node only.
 *
 * @param ancestorView - ancestor view in relation to which, the frame send in state update is computed; if this is
 * `nil` the method does nothing.
 */
- (void)updateShadowStateInContextOfAncestorView:(nullable UIView *)ancestorView;

/**
 * Updates state of the header subview shadow node in shadow tree in context of given ancestor view.
 * This method updates state of header subview shadow node only.
 *
 * @param ancestorView ancestor view in relation to which, the frame send in state update is computed; if this is
 * `nil` the method does nothing.
 * @param frame source frame, which will be transformed in relation to `ancestorView`.
 */
- (void)updateShadowStateInContextOfAncestorView:(nullable UIView *)ancestorView withFrame:(CGRect)frame;

/**
 * Returns UIBarButtonItem associated with this subview. If it doesn't exist, UIBarButtonItem is created.
 */
- (UIBarButtonItem *)getUIBarButtonItem;

@end

#if defined(__cplusplus)
@interface RNSScreenStackHeaderSubviewManager : RCTViewManager
#else
@interface RNSScreenStackHeaderSubviewManager : NSObject
#endif // __cplusplus

@property (nonatomic) RNSScreenStackHeaderSubviewType type;

@end

NS_ASSUME_NONNULL_END
