package com.swmansion.rnscreens.stack.header.subview

import android.view.View

interface StackHeaderSubviewProviding {
    val type: StackHeaderSubviewType
    val collapseMode: StackHeaderSubviewCollapseMode
    val view: View
}
