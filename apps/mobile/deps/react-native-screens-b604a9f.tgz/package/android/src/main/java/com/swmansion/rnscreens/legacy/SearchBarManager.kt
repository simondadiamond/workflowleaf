package com.swmansion.rnscreens.legacy

import com.facebook.react.bridge.JSApplicationIllegalArgumentException
import com.facebook.react.module.annotations.ReactModule
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.uimanager.ViewGroupManager
import com.facebook.react.uimanager.ViewManagerDelegate
import com.facebook.react.viewmanagers.RNSSearchBarManagerDelegate
import com.facebook.react.viewmanagers.RNSSearchBarManagerInterface
import com.swmansion.rnscreens.legacy.events.SearchBarBlurEvent
import com.swmansion.rnscreens.legacy.events.SearchBarChangeTextEvent
import com.swmansion.rnscreens.legacy.events.SearchBarCloseEvent
import com.swmansion.rnscreens.legacy.events.SearchBarFocusEvent
import com.swmansion.rnscreens.legacy.events.SearchBarSearchButtonPressEvent
import com.swmansion.rnscreens.legacy.stack.SearchBarOpenEvent

@ReactModule(name = SearchBarManager.REACT_CLASS)
class SearchBarManager :
    ViewGroupManager<SearchBarView>(),
    RNSSearchBarManagerInterface<SearchBarView> {
    private val delegate: ViewManagerDelegate<SearchBarView>

    init {
        delegate = RNSSearchBarManagerDelegate<SearchBarView, SearchBarManager>(this)
    }

    protected override fun getDelegate(): ViewManagerDelegate<SearchBarView> = delegate

    override fun getName(): String = REACT_CLASS

    override fun createViewInstance(context: ThemedReactContext): SearchBarView = SearchBarView(context)

    override fun onAfterUpdateTransaction(view: SearchBarView) {
        super.onAfterUpdateTransaction(view)
        view.onUpdate()
    }

    override fun setAutoCapitalize(
        view: SearchBarView,
        autoCapitalize: String?,
    ) {
        view.autoCapitalize =
            when (autoCapitalize) {
                null, "systemDefault", "none" -> SearchBarView.SearchBarAutoCapitalize.NONE
                "words" -> SearchBarView.SearchBarAutoCapitalize.WORDS
                "sentences" -> SearchBarView.SearchBarAutoCapitalize.SENTENCES
                "characters" -> SearchBarView.SearchBarAutoCapitalize.CHARACTERS
                else -> throw JSApplicationIllegalArgumentException(
                    "Forbidden auto capitalize value passed",
                )
            }
    }

    override fun setAutoFocus(
        view: SearchBarView,
        autoFocus: Boolean,
    ) {
        view.autoFocus = autoFocus
    }

    override fun setBarTintColor(
        view: SearchBarView,
        color: Int?,
    ) {
        view.tintColor = color
    }

    override fun setDisableBackButtonOverride(
        view: SearchBarView,
        disableBackButtonOverride: Boolean,
    ) {
        view.shouldOverrideBackButton = disableBackButtonOverride != true
    }

    override fun setInputType(
        view: SearchBarView,
        inputType: String?,
    ) {
        view.inputType =
            when (inputType) {
                null, "text" -> SearchBarView.SearchBarInputTypes.TEXT
                "phone" -> SearchBarView.SearchBarInputTypes.PHONE
                "number" -> SearchBarView.SearchBarInputTypes.NUMBER
                "email" -> SearchBarView.SearchBarInputTypes.EMAIL
                else -> throw JSApplicationIllegalArgumentException(
                    "Forbidden input type value",
                )
            }
    }

    override fun setPlaceholder(
        view: SearchBarView,
        placeholder: String?,
    ) {
        if (placeholder != null) {
            view.placeholder = placeholder
        }
    }

    override fun setTextColor(
        view: SearchBarView,
        color: Int?,
    ) {
        view.textColor = color
    }

    override fun setHeaderIconColor(
        view: SearchBarView,
        color: Int?,
    ) {
        view.headerIconColor = color
    }

    override fun setHintTextColor(
        view: SearchBarView,
        color: Int?,
    ) {
        view.hintTextColor = color
    }

    override fun setShouldShowHintSearchIcon(
        view: SearchBarView,
        shouldShowHintSearchIcon: Boolean,
    ) {
        view.shouldShowHintSearchIcon = shouldShowHintSearchIcon ?: true
    }

    override fun getExportedCustomDirectEventTypeConstants(): Map<String, Any> =
        hashMapOf(
            SearchBarBlurEvent.EVENT_NAME to hashMapOf("registrationName" to "onSearchBlur"),
            SearchBarChangeTextEvent.EVENT_NAME to hashMapOf("registrationName" to "onChangeText"),
            SearchBarCloseEvent.EVENT_NAME to hashMapOf("registrationName" to "onClose"),
            SearchBarFocusEvent.EVENT_NAME to hashMapOf("registrationName" to "onSearchFocus"),
            SearchBarOpenEvent.EVENT_NAME to hashMapOf("registrationName" to "onOpen"),
            SearchBarSearchButtonPressEvent.EVENT_NAME to hashMapOf("registrationName" to "onSearchButtonPress"),
        )

    companion object {
        const val REACT_CLASS = "RNSSearchBar"
    }

    // NativeCommands

    override fun blur(view: SearchBarView?) {
        view?.handleBlurJsRequest()
    }

    override fun focus(view: SearchBarView?) {
        view?.handleFocusJsRequest()
    }

    override fun clearText(view: SearchBarView?) {
        view?.handleClearTextJsRequest()
    }

    override fun toggleCancelButton(
        view: SearchBarView?,
        flag: Boolean,
    ) {
        view?.handleToggleCancelButtonJsRequest(flag)
    }

    override fun setText(
        view: SearchBarView?,
        text: String?,
    ) {
        view?.handleSetTextJsRequest(text)
    }

    override fun cancelSearch(view: SearchBarView?) {
        view?.handleCancelSearchJsRequest()
    }

    // iOS only

    override fun setPlacement(
        view: SearchBarView,
        placeholder: String?,
    ) = Unit

    override fun setAllowToolbarIntegration(
        view: SearchBarView,
        value: Boolean,
    ) = Unit

    override fun setHideWhenScrolling(
        view: SearchBarView?,
        value: Boolean,
    ) = Unit

    override fun setObscureBackground(
        view: SearchBarView?,
        value: String?,
    ) = Unit

    override fun setHideNavigationBar(
        view: SearchBarView?,
        value: String?,
    ) = Unit

    override fun setCancelButtonText(
        view: SearchBarView?,
        value: String?,
    ) = Unit

    override fun setTintColor(
        view: SearchBarView?,
        value: Int?,
    ) = Unit
}
