package com.swmansion.rnscreens.scrollviewmarker

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.widget.ScrollView
import androidx.core.view.children
import androidx.core.widget.NestedScrollView
import com.facebook.react.common.annotations.UnstableReactNativeAPI
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.views.view.ReactViewGroup

@OptIn(UnstableReactNativeAPI::class)
@SuppressLint("ViewConstructor") // Should never be inflated / restored
class ScrollViewMarker(
    private val reactContext: ThemedReactContext,
) : ReactViewGroup(reactContext) {
    // region Base override

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        maybeRegisterWithSeekingAncestor()
    }

    override fun onDetachedFromWindow() {
        hasAttemptedRegistration = false
        super.onDetachedFromWindow()
    }

    // endregion

    private var hasAttemptedRegistration: Boolean = false

    /**
     * Currently we discover only ScrollView or NestedScrollView.
     * It'll crash in case scroll view detection fails.
     *
     * Call it only after the children have been already attached and not yet detached.
     *
     * This method intentionally ignores horizontal scroll views - we don't have support for "edge effects"
     * on Android nor we have any other use for them.
     */
    private fun findScrollView(): ViewGroup {
        val childScrollView =
            checkNotNull(children.find { childView -> childView is ScrollView || childView is NestedScrollView }) {
                "[RNScreens] Failed to find supported type of ScrollView in children of ScrollViewMarker"
            }

        return childScrollView as ViewGroup
    }

    private fun findFirstSeekingAncestor(): ScrollViewSeeking? {
        var currentView = parent

        while (currentView != null) {
            if (currentView is ScrollViewSeeking) {
                return currentView
            }
            currentView = currentView.parent
        }

        return null
    }

    private fun registerWithSeekingAncestor() {
        val scrollView = findScrollView()
        findFirstSeekingAncestor()?.registerScrollView(this, scrollView)
    }

    private fun maybeRegisterWithSeekingAncestor() {
        if (hasAttemptedRegistration) {
            return
        }

        registerWithSeekingAncestor()
        hasAttemptedRegistration = true
    }

    internal fun onViewManagerDropViewInstance() = Unit
}
